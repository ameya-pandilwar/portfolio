package com.cs6240.msd

import org.apache.spark.SparkContext

object splitTrainAndTest {

  def main(args: Array[String]): Unit = {
      val sc = new SparkContext("local", "Simple App");  
  }
}