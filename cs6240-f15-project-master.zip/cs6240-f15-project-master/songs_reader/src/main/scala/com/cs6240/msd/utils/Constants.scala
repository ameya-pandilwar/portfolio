package com.cs6240.msd.utils

object Constants {

	val ARTISTID:String = "ArtistId";
	val COLUMN_FAMILY:String ="cf";
	val YEAR:String = "year";
	val YEAR_RANGE=10.0;
	val YEAR_START=1920.0;
	val YEAR_END=2020.0;
}