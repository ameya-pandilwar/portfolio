package edu.neu.husky.a.pandilwar;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 * This class implements a custom partitioner that assigns words to the reduce tasks.
 * 
 * @author Ameya Pandilwar
 */
public class CustomPartitioner extends Partitioner<Text, IntWritable> {

	@Override
	public int getPartition(Text key, IntWritable value, int numReduceTasks) {
		char firstLetter = key.toString().toLowerCase().charAt(0);
		int numTask = 0;
		switch (firstLetter) {
			case 'm': numTask = 0;
					  break;
			case 'n': numTask = 1;
					  break;
			case 'o': numTask = 2;
					  break;
			case 'p': numTask = 3;
					  break;
			case 'q': numTask = 4;
					  break;
			default : break;
		}
		return numTask;
	}
}