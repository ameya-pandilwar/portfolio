package edu.neu.husky.a.pandilwar;

import java.util.regex.Pattern;

/**
 * This class is used for defining methods that are used commonly throughout the program. 
 * 
 * @author Ameya Pandilwar
 */
public final class Utilities {
	
	/**
	 * The pattern for identifying "real" words irrespective of it's case 
	 */
	private static final String REAL_WORD_PATTERN = "[m-q].*";
	
	private static Pattern pattern;
	
	/**
	 * @param word		the word which is to be checked
	 * @return 			true iff the given word qualifies as a real word based on the 
	 * 					given definition; false otherwise.
	 */
	public static boolean isRealWord(String word) {
		if (pattern == null) {
			pattern = Pattern.compile(REAL_WORD_PATTERN, Pattern.CASE_INSENSITIVE);
		}
		return pattern.matcher(word).matches();
	}
}