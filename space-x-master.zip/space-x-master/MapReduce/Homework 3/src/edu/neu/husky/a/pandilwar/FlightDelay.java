package edu.neu.husky.a.pandilwar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.opencsv.CSVParser;

import edu.neu.husky.a.pandilwar.FlightUtilities.Config;

/**
 * This class is used for calculating the average flight delay. 
 * 
 * @author Ameya Pandilwar
 */
public class FlightDelay {

	public enum Counters { TOTAL_DELAY, TOTAL_FLIGHTS }

	/**
	 * The mapper class for calculating the average flight delay.
	 */
	public static class FlightDelayMapper extends Mapper<Object, Text, Text, Text> {

		private CSVParser csvParser = new CSVParser(',','"');

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String[] line = csvParser.parseLine(value.toString());
			Text mapKey = new Text(), mapValue = new Text();

			if (FlightUtilities.isValidRecord(line)) {				
				String mapRecord = FlightUtilities.prepareMapOutputRecord(line);
				mapKey.set(line[5] + Config.SEPARATOR + (mapRecord.contains(Config.ORIGIN) ? line[17] : line[11]));
				mapValue.set(mapRecord);
				context.write(mapKey, mapValue);
			}
		}
	}

	/**
	 * The reducer class for calculating the average flight delay.
	 */
	public static class FlightDelayReducer extends Reducer<Text, Text, Text, Text> {

		private CSVParser csvParser = new CSVParser(',','"');;
		private int totalFlights;
		private float totalDelay;
		
		public void setup(Context context){
			totalFlights = 0; 
			totalDelay = 0;
		}

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {	
			List<String> flightsDepartedOrigin = new ArrayList<String>();
			List<String> flightsReachedDestination = new ArrayList<String>();

			for (Text value : values) {
				String record = value.toString();
				if (record.contains(Config.ORIGIN)) {
					flightsDepartedOrigin.add(record);
				} else {
					flightsReachedDestination.add(record);
				}
			}

			for (String departedFlight : flightsDepartedOrigin) {
				String[] departedInfo = csvParser.parseLine(departedFlight);
				
				for (String arrivedFlight : flightsReachedDestination) {
					String[] arrivedInfo = csvParser.parseLine(arrivedFlight);

					if (FlightUtilities.isTwoLegFlight(departedInfo, arrivedInfo)) {
						totalDelay += Float.parseFloat(departedInfo[3]) + Float.parseFloat(arrivedInfo[3]);
						totalFlights++;
					}
				}	
			}
		}

		public void cleanup(Context context) throws IOException, InterruptedException {
			context.getCounter(Counters.TOTAL_DELAY).increment((long) totalDelay);
			context.getCounter(Counters.TOTAL_FLIGHTS).increment(totalFlights);

			context.write(new Text(String.valueOf(context.getCounter(Counters.TOTAL_DELAY).getValue())),
					new Text(String.valueOf(context.getCounter(Counters.TOTAL_FLIGHTS).getValue())));
		}
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "average flight delay");
		job.setJarByClass(FlightDelay.class);
		job.setMapperClass(FlightDelayMapper.class);
		job.setReducerClass(FlightDelayReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}