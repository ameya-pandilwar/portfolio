package edu.neu.husky.a.pandilwar;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This class is used for defining methods that are used frequently throughout the program. 
 * 
 * @author Ameya Pandilwar
 */
public class FlightUtilities {

	/**
	 *
	 */
	public class Config {
		public static final String START_DATE = "2007-06-01";
		public static final String END_DATE = "2008-05-31";
		public static final String ORIGIN = "ORD";
		public static final String DESTINATION = "JFK";
		public static final String YES_INDICATOR = "1";
		public static final String DATE_FORMAT = "yyyy-MM-dd";
		public static final String DELIMITER = ",";
		public static final String SEPARATOR = ":";

		// for debug purposes
		public static final String START_DATE_DEBUG = "2007-12-01";
		public static final String END_DATE_DEBUG = "2008-01-31";
	}

	/**
	 * Determines the validness of the record based on the criteria for computing the average delay.
	 * @param record
	 * @return true iff the record satisfies the given criteria, false otherwise.
	 */
	public static boolean isValidRecord(String[] record) {
		// checking if record is not empty
		if (record == null || record.length == 0) {
			return false;
		}
		// ensuring that relevant mandatory fields are not empty
		if (record[0].isEmpty() || record[2].isEmpty() || record[5].isEmpty() || record[11].isEmpty() ||
				record[17].isEmpty() || record[24].isEmpty() || record[35].isEmpty() || 
				record[37].isEmpty() || record[41].isEmpty() || record[43].isEmpty()) {
			return false;
		}
		// ensuring that it is not a direct flight 
		if (record[11].equalsIgnoreCase(Config.ORIGIN) && record[17].equalsIgnoreCase(Config.DESTINATION)) {
			return false;
		}
		// ensuring that the flight is either matching the origin or destination as per criteria
		if (!(record[11].equalsIgnoreCase(Config.ORIGIN) || record[17].equalsIgnoreCase(Config.DESTINATION))) {
			return false;
		}
		// checking that the flight is not cancelled or diverted
		if (record[41].equals(Config.YES_INDICATOR) || record[43].equals(Config.YES_INDICATOR)) {
			return false;
		}
		// checking if the flight journey is within the stipulated time frame
		SimpleDateFormat format = new SimpleDateFormat(Config.DATE_FORMAT);
		try {
			Date date = format.parse(record[5]);
//			if (date.before(format.parse(Config.START_DATE_DEBUG)) || date.after(format.parse(Config.END_DATE_DEBUG))) {
			if (date.before(format.parse(Config.START_DATE)) || date.after(format.parse(Config.END_DATE))) {
				return false;
			}
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	/**
	 * Prepares the value of the map function output by combining relevant information about the flight details.
	 * @param record
	 * @return the text with the relevant fields for computing.
	 */
	public static String prepareMapOutputRecord(String[] record){
		StringBuilder output = new StringBuilder();

		output.append(record[11])						//Origin
		.append(Config.DELIMITER).append(record[24])	//DepTime
		.append(Config.DELIMITER).append(record[35])	//ArrTime
		.append(Config.DELIMITER).append(record[37]);	//ArrDelayMinutes

		return output.toString();						//<<Origin>>;<<DepTime>>;<<ArrTime>>;<<ArrDelayMinutes>>
	}

	/**
	 * Ensures that the departure time of the second flight is later than the arrival time of the first flight.
	 * @param originInfo
	 * @param destinationInfo
	 * @return true iff the flight is a two-leg flight, false otherwise.
	 */
	public static boolean isTwoLegFlight(String[] originInfo, String[] destinationInfo) {
		return Integer.parseInt(originInfo[2]) < Integer.parseInt(destinationInfo[1]);
	}
	
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		File resultFolder = new File(args[0]);
		String[] files = resultFolder.list();
		long count = 0;
		double totalDelay = 0;
		for (String file : files) {
			if (!file.startsWith(".") && !file.startsWith("_")) {
				BufferedReader reader = new BufferedReader(new FileReader(args[0] + "/" + file));
				String[] line = reader.readLine().split("\t");
				totalDelay += Double.valueOf(line[0]);
				count += Long.valueOf(line[1]);
				reader.close();
			}
		}
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(args[0] + "/averageFlightDelay.txt")));
		writer.write(String.format("%.6f", totalDelay / count));
		writer.flush();
		writer.close();
	}

}