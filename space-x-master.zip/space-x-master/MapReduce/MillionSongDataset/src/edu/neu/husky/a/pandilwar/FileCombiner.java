package edu.neu.husky.a.pandilwar;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class FileCombiner {

	static String fileName = "opAHvsAF";
	static String outputDir = "/Users/ameyapandilwar/Desktop/" + fileName;
	
	public static void main(String[] args) throws Exception {
		File resultFolder = new File(outputDir);
		String[] files = resultFolder.list();
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(outputDir + ".csv")));
		
		for (String file : files) {
			if (!file.startsWith(".") && !file.startsWith("_")) {
				BufferedReader reader = new BufferedReader(new FileReader(outputDir + "/" + file));
				String sCurrentLine;

				while ((sCurrentLine = reader.readLine()) != null) {
					writer.write(sCurrentLine);
					writer.write("\n");
				}

				reader.close();
			}
		}		
		
		writer.flush();
		writer.close();
	}

}