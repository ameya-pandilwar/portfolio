package edu.neu.husky.a.pandilwar;

import java.io.File;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.opencsv.CSVParser;

/**
 * This class is used for calculating the monthly flight delay pattern. 
 * 
 * @author Ameya Pandilwar
 */
public class MSDTaskOneB {

	/**
	 * The mapper class for the million song dataset.
	 */
	public static class MSDMapper extends Mapper<Object, Text, Text, Text> {

		private CSVParser csvParser = new CSVParser('\t','"');

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			try {
				String[] line = csvParser.parseLine(value.toString());
				Text mapKey = new Text(), mapValue = new Text();
				mapKey.set(line[2]);
				mapValue.set(line[7]);
				context.write(mapKey, mapValue);
			} catch (Exception e) {

			}
		}
	}

	/**
	 * The reducer class for the million song dataset.
	 */
	public static class MSDReducer extends Reducer<Text, Text, Text, Text> {

		private Text result = new Text();

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			try {
				int count = 0;
				double tempo = 0;

				for (Text value : values) {
					count += 1;
					tempo += Double.parseDouble(value.toString());
				}
				result.set(String.valueOf(tempo / count));
				context.write(key, result);
			} catch (Exception e) {

			}
		}

	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

//		File directory = new File(args[1]);
//		if (directory.exists()) {
//			try {
//				delete(directory);
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}

		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "million song dataset -- task two");
		job.setJarByClass(MSDTaskOneB.class);
		job.setMapperClass(MSDMapper.class);
		job.setReducerClass(MSDReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

	public static void delete(File file) throws IOException{
		if (file.isDirectory()) {
			if (file.list().length==0) {
				file.delete();
				System.out.println("Directory is deleted : " + file.getAbsolutePath());
			} else {
				String files[] = file.list();

				for (String temp : files) {
					File fileDelete = new File(file, temp);
					delete(fileDelete);
				}

				if (file.list().length == 0) {
					file.delete();
					System.out.println("Directory is deleted : " + file.getAbsolutePath());
				}
			}
		} else {
			file.delete();
			System.out.println("File is deleted : " + file.getAbsolutePath());
		}
	}

}