module.exports = function(app, mongoose, db){

//    var model = require("./models/event.model.js")(mongoose, db);
//    require("./services/event.service.server.js")(app, model);


// var model = require("./models/user.model.js")(mongoose, db);
//    require("./services/user.service.server.js")(app, model);

//Uncomment for loading Categories in database
// var model = require("./models/categories.model.js")(mongoose, db);
//    require("./services/home.service.server.js")(app, model);

};